from flask import Blueprint

master = Blueprint('master', __name__)
