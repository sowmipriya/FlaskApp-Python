MONGO_DBNAME = 'register'
MONGO_URI = 'mongodb://localhost:27017/register'
