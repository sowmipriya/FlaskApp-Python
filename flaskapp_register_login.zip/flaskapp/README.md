# flask-registration-login-wtforms-validators
User Registration / Login using Flask and MongoDB

Install Required packages

Register with required data

Login with the username, email, password

View corona data in user profile.


Command to run : python manage.py runserver
Home page : /
Login : /sign
Register : /register
